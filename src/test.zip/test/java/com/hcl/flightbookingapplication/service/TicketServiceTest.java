package com.hcl.flightbookingapplication.service;


import java.util.Date;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import com.hcl.flightbookingapplication.dao.BookingRepository;
import com.hcl.flightbookingapplication.dto.TicketDetailsDto;
import com.hcl.flightbookingapplication.model.Booking;

@RunWith(MockitoJUnitRunner.Silent.class)
public class TicketServiceTest {
	@InjectMocks
	TicketServiceImpl ticketServiceImpl;
	@Mock
	BookingRepository bookingRepository;
	static TicketDetailsDto dto=new TicketDetailsDto();
	static Booking booking=null;
	@BeforeClass
	public static void setUp() {
		booking=new Booking();
		booking.setTicketNumber(23335);
		dto =new TicketDetailsDto();
		dto.setPassengerName("divya");
		dto.setDestination("chennai");
		dto.setAmmount(122);
		dto.setDepartureDate(new Date());
		dto.setEmial("divay@gmil.com");
		dto.setFlightName("indgo");
		dto.setNoOfSeats(2);
		dto.setOrigin("ongole");
		
	}
	@Test
	public void testForGetByTicketNumber() {
		Mockito.when(bookingRepository.getOne(booking.getTicketNumber())).thenReturn(booking);
		ticketServiceImpl.getTicketById(booking.getTicketNumber());
		Assert.assertEquals(booking.getTicketNumber(), dto.getTicketNumber());
		
	}

}
