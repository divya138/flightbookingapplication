package com.hcl.flightbookingapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightbookingapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
